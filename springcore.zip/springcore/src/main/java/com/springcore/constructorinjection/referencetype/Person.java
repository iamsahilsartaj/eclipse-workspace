package com.springcore.constructorinjection.referencetype;

public class Person {
	private String name;
	private int personId;
	private Address personAddress;
	
	// constructor with arguments
	public Person(String name, int personId, Address personAddress) {
		super();
		this.name = name;
		this.personId = personId;
		this.personAddress = personAddress;
	}

	@Override
	public String toString() {
		return this.name+": "+this.personId+" from state of "+this.personAddress;
	}
	
	
	

}
