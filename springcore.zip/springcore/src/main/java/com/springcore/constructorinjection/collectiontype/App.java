package com.springcore.constructorinjection.collectiontype;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/springcore/constructorinjection/collectiontype/config.xml");
		Student student= (Student) context.getBean("stud");
		
		System.out.println(student);

	}

}
