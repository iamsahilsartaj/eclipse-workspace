package com.springcore.constructorinjection.referencetype;

public class Address {
	private String state;
	
	Address(String state) {
		super();
		this.state=state;
	}

	@Override
	public String toString() {
		return this.state;
	}
	
	

}
