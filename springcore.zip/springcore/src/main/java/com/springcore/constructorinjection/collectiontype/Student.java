package com.springcore.constructorinjection.collectiontype;

import java.util.List;
import java.util.Map;

public class Student {
	private String name;
	private Map<String, Integer> studMarks;
	
	public Student(String name, Map<String, Integer> studMarks) {
		super();
		this.name = name;
		this.studMarks = studMarks;
	}

	@Override
	public String toString() {
		return "Student [name=" + name + ", studMarks=" + studMarks + "]";
	}
	
	
	
	

}
