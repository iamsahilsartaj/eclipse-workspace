package com.springcore.reference;

public class Car {
	private String model;
	private Engine en;
	
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public Engine getEn() {
		return en;
	}
	public void setEn(Engine en) {
		this.en = en;
	}
	
	public Car(String model, Engine en) {
		super();
		this.model = model;
		this.en = en;
	}
	
	public Car() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "Car [model=" + model + ", en=" + en + "]";
	}
	
	
	

}
