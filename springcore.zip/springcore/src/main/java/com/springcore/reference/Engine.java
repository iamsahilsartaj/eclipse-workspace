package com.springcore.reference;

public class Engine {
	private int Y;

	public int getY() {
		return Y;
	}

	public void setY(int y) {
		Y = y;
	}

	public Engine(int y) {
		super();
		Y = y;
	}

	public Engine() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Engine [Y=" + Y + "]";
	}
	

}
