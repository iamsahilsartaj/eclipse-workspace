package com.springcore.javaconfig;

public class Samosa {
	
	public void price() {
		System.out.println("Price of Samosa is 10 rupess");
	}

}
