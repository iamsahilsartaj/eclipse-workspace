package com.springcore.javaconfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
// @ComponentScan(basePackages = "com.springcore.javaconfig")
public class JavaConfig {
	
	@Bean
	public Samosa getSamosaBean() {
		// return samosa object
		return new Samosa();
	}
	
	@Bean(name = {"student", "stud"})
	public Student getStudentBean() {
		
		//creating a new student object
		Student student =  new Student(getSamosaBean());
		
		return student;
	}

}
