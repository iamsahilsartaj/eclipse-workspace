package com.springcore.beanscope;

public class Teacher {
	
	// this class used to the xml scope example

}
