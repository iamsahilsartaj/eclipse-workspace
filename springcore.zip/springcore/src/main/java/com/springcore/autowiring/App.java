package com.springcore.autowiring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.springcore.collection.Employee;

public class App {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/springcore/autowiring/autowireconfig.xml");
		Emp emp =  context.getBean("emp",Emp.class); // Emp.class typecasted to Emp 
		
		System.out.println(emp);

	}

}
