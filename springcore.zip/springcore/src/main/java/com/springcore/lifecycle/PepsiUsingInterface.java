package com.springcore.lifecycle;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class PepsiUsingInterface implements InitializingBean, DisposableBean{
	private double price;

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public PepsiUsingInterface(double price) {
		super();
		this.price = price;
	}

	public PepsiUsingInterface() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "PepsiUsingInterface [price=" + price + "]";
	}

	// creation of bean
	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("Inside init method || using Interface");		
	}
	
	// destroying bean
	@Override
	public void destroy() throws Exception {
		System.out.println("Inside destroy method || using Interface");		
	}


	
	

}
