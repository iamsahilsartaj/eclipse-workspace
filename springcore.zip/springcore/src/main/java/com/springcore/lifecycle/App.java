package com.springcore.lifecycle;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
	AbstractApplicationContext context = new ClassPathXmlApplicationContext("com/springcore/lifecycle/lifecycleconfig.xml");
	
	// register shutdown or destroy the bean
	context.registerShutdownHook();
	
	// samosa bean for implementing bean life-cycle using xml
	Samosa sa1 = (Samosa)context.getBean("s1");	
	System.out.println(sa1);
	
	System.out.println("++++++++++++++++++++++++++++++++++++++++++");
	
	// pepsi bean for implementing bean life-cycle using interface
	PepsiUsingInterface pepsi = (PepsiUsingInterface) context.getBean("p1");
	System.out.println(pepsi);
	
	System.out.println("++++++++++++++++++++++++++++++++++++++++++");
	
	
	Example example = (Example) context.getBean("example");
	System.out.println(example);

	}

}
